// ==================================
//            AXIOS for API
// ==================================
var axios = require("axios");

// ==================================
//             Helper function for API call
// ==================================

export const helper = () => {
    console.log(axios);
}
    


// module.exports = helper;