// import grandchild files
import ChiLocal from "./local/Chicago"
import ChiTourist from "./tourist/Chicago"

// Require react dependencies
import React from "react";
import Link from "react-router";

class Chicago extends React.Component {
    render() {
        return (
            <div>
                <h1>
                    Chicago
                </h1>
                <Link to="/ChiLocal"><button className="btn btn-secondary">Local</button></Link>
                <Link to="/ChiTourist"><button className="btn btn-secondary">Tourist</button></Link>
            </div>
        )
    }
};

export { Chicago as default };